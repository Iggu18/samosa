function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function draw() {
  background('#F5EAB3'); 


  noStroke();
  fill('#3A5A40'); 
  triangle(50, 350, 200, 100, 350, 350); 

  fill('#B85C38'); 
  triangle(0, 400, 200, 250, 400, 400); 
}
